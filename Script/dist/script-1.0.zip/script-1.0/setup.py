from distutils.core import setup

setup(name='script',
      version='1.0',
      py_modules=['define','GUI','Script']
      )
